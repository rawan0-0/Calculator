// Get the input field and buttons
const resultField = document.getElementById("result");
const clearButton = document.querySelector(".operator:nth-child(1)");
const backspaceButton = document.querySelector(".operator:nth-child(2)");
const divideButton = document.querySelector(".operator:nth-child(3)");
const multiplyButton = document.querySelector(".operator:nth-child(4)");
const subtractButton = document.querySelector(".operator:nth-child(8)");
const addButton = document.querySelector(".operator:nth-child(12)");
const equalsButton = document.querySelector(".operator:nth-child(16)");
const numberButtons = document.querySelectorAll(".number");

// Initialize variables
let currentResult = "";
let prevResult = "";
let currentOperator = "";

// Append a character to the result field
function appendToResult(char) {
  currentResult += char;
  resultField.value = currentResult;
}

// Calculate the result
function calculate(operator) {
  if (operator === "=") {
    if (currentOperator === "+") {
      currentResult = parseFloat(prevResult) + parseFloat(currentResult);
    } else if (currentOperator === "-") {
      currentResult = parseFloat(prevResult) - parseFloat(currentResult);
    } else if (currentOperator === "*") {
      currentResult = parseFloat(prevResult) * parseFloat(currentResult);
    } else if (currentOperator === "/") {
      currentResult = parseFloat(prevResult) / parseFloat(currentResult);
    }
    prevResult = "";
    currentOperator = "";
  } else {
    if (prevResult === "") {
      prevResult = currentResult;
      currentResult = "";
    } else {
      if (currentOperator === "+") {
        prevResult = parseFloat(prevResult) + parseFloat(currentResult);
      } else if (currentOperator === "-") {
        prevResult = parseFloat(prevResult) - parseFloat(currentResult);
      } else if (currentOperator === "*") {
        prevResult = parseFloat(prevResult) * parseFloat(currentResult);
      } else if (currentOperator === "/") {
        prevResult = parseFloat(prevResult) / parseFloat(currentResult);
      }
      currentResult = "";
    }
    currentOperator = operator;
  }
  resultField.value = currentResult !== "" ? currentResult : prevResult;
}

// Clear the result field
function clearResult() {
  currentResult = "";
  prevResult = "";
  currentOperator = "";
  resultField.value = "";
}

// Delete the last character in the result field
function backspace() {
  currentResult = currentResult.slice(0, -1);
  resultField.value = currentResult;
}

// Attach event listeners to buttons
clearButton.addEventListener("click", clearResult);
backspaceButton.addEventListener("click", backspace);
divideButton.addEventListener("click", () => calculate("/"));
multiplyButton.addEventListener("click", () => calculate("*"));
subtractButton.addEventListener("click", () => calculate("-"));
addButton.addEventListener("click", () => calculate("+"));
equalsButton.addEventListener("click", () => calculate("="));
numberButtons.forEach((button) => {
  button.addEventListener("click", () => appendToResult(button.textContent));
});
